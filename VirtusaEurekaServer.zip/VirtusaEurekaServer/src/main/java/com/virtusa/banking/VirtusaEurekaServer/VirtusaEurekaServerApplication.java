package com.virtusa.banking.VirtusaEurekaServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VirtusaEurekaServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(VirtusaEurekaServerApplication.class, args);
	}
}
