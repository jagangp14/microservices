package com.virtusa.banking.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


import feign.auth.BasicAuthRequestInterceptor;

@RestController
public class CustomerController {
    @Autowired  
 	private CustomerServiceProxy customerServiceProxy;
	
	@GetMapping(value="/getfeigncustomers")
	public String getFeignAssetData()
	{
		
		ResponseEntity<String> responseEntity=customerServiceProxy.retrieveAssets();
		
		return responseEntity.getBody();
	}
	
}
