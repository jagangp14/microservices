package com.virtusa.banking.models;

import java.util.Date;


import com.fasterxml.jackson.annotation.JsonFormat;

public class Customer {
	
	private long customerId;
	
	private String firstName;
	
	private String lastName;
	
	
	private Date dob;
	public long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	
	
	

}
