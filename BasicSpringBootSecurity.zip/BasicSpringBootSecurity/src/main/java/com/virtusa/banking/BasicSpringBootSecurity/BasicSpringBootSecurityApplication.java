package com.virtusa.banking.BasicSpringBootSecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasicSpringBootSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(BasicSpringBootSecurityApplication.class, args);
	}
}
