package com.virtusa.banking.ConsulServer;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ConsulServerApplicationTests {

	@Test
	public void contextLoads() {
	}

}
