package com.hsbc.banking.aspects;

import java.util.logging.Logger;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class EventAspect {
	Logger logger=Logger.getLogger(getClass().getName());
	
	@Before("execution(void com.hsbc.banking.models.*.set*(*))")
	public void invokeSetters(JoinPoint joinPoint)
	{
		logger.info("Setter Method Logger Before invocation......");
		logger.info(joinPoint.getSignature().getName());
		logger.info(joinPoint.getSourceLocation().getFileName());
		logger.info(joinPoint.getTarget().getClass().getName());
		
	}
	@Before("execution(* com.hsbc.banking.models.*.get*())")
	public void invokeGetters(JoinPoint joinPoint)
	{

		logger.info("Getter Method Logger Before invocation......");
		logger.info(joinPoint.getSignature().getName());
		logger.info(joinPoint.getSourceLocation().getFileName());
		logger.info(joinPoint.getTarget().getClass().getName());
	}
	@After("execution(void com.hsbc.banking.models.*.set*(*))")
	public void invokeAfterSetters(JoinPoint joinPoint)
	{

		logger.info("Setter Method Logger After invocation......");
		logger.info(joinPoint.getSignature().getName());
		logger.info(joinPoint.getSourceLocation().getFileName());
		logger.info(joinPoint.getTarget().getClass().getName());
	}
	@After("execution(* com.hsbc.banking.models.*.get*())")
	public void invokeAfterGetters(JoinPoint joinPoint)
	{

		logger.info("Getter Method Logger After invocation......");
		logger.info(joinPoint.getSignature().getName());
		logger.info(joinPoint.getSourceLocation().getFileName());
		logger.info(joinPoint.getTarget().getClass().getName());
	}
	@AfterReturning("execution(void com.hsbc.banking.models.*.set*(*))")
	public void invokeAfterReturningSetters(JoinPoint joinPoint)
	{

		logger.info("Setter Method Logger After Returning ......");
		logger.info(joinPoint.getSignature().getName());
		logger.info(joinPoint.getSourceLocation().getFileName());
		logger.info(joinPoint.getTarget().getClass().getName());
	}

}
