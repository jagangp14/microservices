package com.hsbc.banking.utility;

import java.time.LocalDate;

import com.hsbc.banking.models.Event;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Event event=new Event();
		event.setEventId(47567);
		event.setName("Conference");
		event.setLocation("Mumbai");
        event.setEventDate(LocalDate.of(2019,4,4));	
        System.out.println(event.getEventId());
        System.out.println(event.getName());
        System.out.println(event.getLocation());
	}

}
