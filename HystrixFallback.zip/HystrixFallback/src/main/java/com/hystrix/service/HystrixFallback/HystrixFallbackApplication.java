package com.hystrix.service.HystrixFallback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HystrixFallbackApplication {

	public static void main(String[] args) {
		SpringApplication.run(HystrixFallbackApplication.class, args);
	}
}
